package funcionarios;

// 5) Crie uma classe Java chamada Operador que seja uma subclasse de Funcionario, com o seguinte
// atributo: valorHora. O campo deve estar definido como privado, além disso, defina os métodos getters
// / setters (conforme padrão Java) para prover acesso ao campo privado.

public class Operador extends Funcionario {

  private double valorHora;

// getters/setters

  public double getValorHora() {
    return valorHora;
  }

  public void setValorHora(double valorHora) {
    this.valorHora = valorHora;
  }

}
