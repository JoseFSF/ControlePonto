package funcionarios;

// 4) Crie uma classe Java chamada Secretaria que seja uma subclasse de Funcionario, com os
// seguintes atributos: telefone e ramal. Os campos devem estar definidos como privados, além disso,
// defina os métodos getters / setters para prover acesso ao campo.

public class Secretaria extends Funcionario {
  private String telefone;
  private String ramal;

// getters/setters

  public String getTelefone() {
    return telefone;
  }

  public void setTelefone(String telefone) {
    this.telefone = telefone;
  }

  public String getRamal() {
    return ramal;
  }

  public void setRamal(String ramal) {
    this.ramal = ramal;
  }
}
