import java.time.LocalDateTime;
import java.time.LocalDate;

import funcionarios.*;

// 1)  Crie um projeto Java chamado ControlePonto. A classe que contém o método main deve ser
// chamada de GerenciarControlePonto.

public class GerenciarControlePonto {
  public static void main(String[] args) {

    // 8) Instancie um Gerente e popule os dados.
    Gerente gerente = new Gerente();
    gerente.setIdFunc(1);
    gerente.setNome("Gerente João");
    gerente.setEmail("joao@empresa.com");
    gerente.setLogin("joao");
    gerente.setSenha("senhajoao");
    gerente.setDocumento("DocGerenteJoão");

    try {
      Thread.sleep(1000);
    } catch(Exception e){
      e.printStackTrace();
    }

    // 9) Instancie uma Secretaria e popule os dados.
    Secretaria secretaria = new Secretaria();
    secretaria.setIdFunc(2);
    secretaria.setNome("Secretaria Maria");
    secretaria.setEmail("maria@empresa.com");
    secretaria.setRamal("101");
    secretaria.setTelefone("3863-1111");
    secretaria.setDocumento("DocSecretariaMaria");

    try {
      Thread.sleep(1000);
    } catch(Exception e){
      e.printStackTrace();
    }

    // 10) Instancie uma Operador e popule os dados.
    Operador operador = new Operador();
    operador.setIdFunc(3);
    operador.setNome("Operador Zé");
    operador.setEmail("ze@empresa.com");
    operador.setValorHora(100d);
    operador.setDocumento("DocOperadorZe");

    try {
      Thread.sleep(1000);
    } catch(Exception e){
      e.printStackTrace();
    }

    // 11) Registre a entrada na empresa do Gerente, apresentado no console os dados da entrada.
    // Lembre-se que os métodos estão na classe RegistroPonto. Nota: cada lançamento de
    // entrada/saída no dia para o funcionário trata-se de uma nova instância de Registro.
    RegistroPonto registroGerente = new RegistroPonto();
    registroGerente.setIdRegPonto(1);
    registroGerente.setFunc(gerente);
    registroGerente.setDataRegistro(LocalDate.now());
    registroGerente.setHoraEntrada(LocalDateTime.now());
    registroGerente.apresentarRegistroPonto();

    try {
      Thread.sleep(1000);
    } catch(Exception e){
      e.printStackTrace();
    }

    // 12) Registre a entrada na empresa da Operador, apresentado no console os dados da entrada.
    RegistroPonto registroOperador = new RegistroPonto();
    registroOperador.setIdRegPonto(2);
    registroOperador.setFunc(operador);
    registroOperador.setDataRegistro(LocalDate.now());
    registroOperador.setHoraEntrada(LocalDateTime.now());
    registroOperador.apresentarRegistroPonto();

    try {
      Thread.sleep(1000);
    } catch(Exception e){
      e.printStackTrace();
    }

    // 13) Registre a entrada na empresa da Secretaria, apresentado no console os dados da entrada.
    RegistroPonto registroSecretaria = new RegistroPonto();
    registroSecretaria.setIdRegPonto(3);
    registroSecretaria.setFunc(secretaria);
    registroSecretaria.setDataRegistro(LocalDate.now());
    registroSecretaria.setHoraEntrada(LocalDateTime.now());
    registroSecretaria.apresentarRegistroPonto();

    try {
      Thread.sleep(1000);
    } catch(Exception e){
      e.printStackTrace();
    }

    // 14) Registre a saída do Gerente, apresentado no console os dados da saída.
    registroGerente.setHoraSaida(LocalDateTime.now());
    registroGerente.apresentarRegistroPonto();

    try {
      Thread.sleep(1000);
    } catch(Exception e){
      e.printStackTrace();
    }

    // 15) Registre a saída da Operador, apresentado no console os dados da saída.
    registroOperador.setHoraSaida(LocalDateTime.now());
    registroOperador.apresentarRegistroPonto();

    try {
      Thread.sleep(1000);
    } catch(Exception e){
      e.printStackTrace();
    }

    // 16) Registre a saída da Secretaria, apresentado no console os dados da saída.
    registroSecretaria.setHoraSaida(LocalDateTime.now());
    registroSecretaria.apresentarRegistroPonto();

    try {
      Thread.sleep(1000);
    } catch(Exception e){
      e.printStackTrace();
    }

    // 17) Acrescente um tempo de um segundo entre cada registro. Pesquise sobre o método sleep da
    // classe Thread.

  }
}
