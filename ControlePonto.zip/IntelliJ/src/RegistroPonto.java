import java.time.LocalDate;
import java.time.LocalDateTime;
import funcionarios.Funcionario;

// 6) Crie uma classe Java chamada RegistroPonto, com os seguintes atributos: idRegPonto, func do
// tipo funcionário, dataRegistro do tipo LocalDate, horaEntrada do tipo LocalDateTime e horaSaida do
// tipo LocalDateTime. Os campos devem estar definidos como privados, além disso, defina os métodos
// getters / setters para prover acesso ao campo.

public class RegistroPonto {

  private int idRegPonto;
  private Funcionario func;
  private LocalDate dataRegistro;
  private LocalDateTime horaEntrada;
  private LocalDateTime horaSaida;

// getters/setters

  public int getIdRegPonto() {
    return idRegPonto;
  }

  public void setIdRegPonto(int idRegPonto) {
    this.idRegPonto = idRegPonto;
  }

  public Funcionario getFunc(){
    return func;
  }

  public void setFunc(Funcionario func) {
    this.func = func;
  }

  public LocalDate getDataRegistro() {
    return dataRegistro;
  }

  public void setDataRegistro(LocalDate dataRegistro) {
    this.dataRegistro = dataRegistro;
  }

  public LocalDateTime getHoraEntrada() {
    return horaEntrada;
  }

  public void setHoraEntrada(LocalDateTime horaEntrada) {
    this.horaEntrada = horaEntrada;
  }

  public LocalDateTime getHoraSaida() {
    return horaSaida;
  }

  public void setHoraSaida(LocalDateTime horaSaida) {
    this.horaSaida = horaSaida;
  }

// 7) Na Classe RegistroPonto acrescente o método apresentarRegistroPonto(), que deverá
// apresentar os dados com o nome do funcionário a data de registro do ponto e os horários de
// entrada e de saída respectivamente. (sout).

  public void apresentarRegistroPonto() {
    Funcionario funcionario = new Funcionario();
    System.out.println("=====================");
    System.out.println(String.format("Funcionário: %s", getFunc().getNome()));
    System.out.println(String.format("Data de Registro: %s", getDataRegistro()));
    System.out.println(String.format("Horário Entrada: %s", getHoraEntrada()));
    System.out.println(String.format("Horário Saída: %s", getHoraSaida()));
  }
}
